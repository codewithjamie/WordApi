<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class RegisterController extends Controller
{
    
    public function RegisterUser(Request $request)
    {
        $checkEmailExisting = User::where('email', '=', $request->email)->exists();

        if ($checkEmailExisting == true)
        {
            return response()->json([
                'status' => false,
                'message' => "Email already existing",
            ], 200);
            exit;
        }
        else {
            
            $user = new User();

            $user-> name = $request->name;
            $user->email = $request->email;
            $user->unique_id = Str::uuid()->toString();
            $user->password = Hash::make($request->password);
            $user->save();

            return response()->json([
                'status' => true,
                'data' => $user,
            ], 200);
        }

        
    }
}
