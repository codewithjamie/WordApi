<?php

namespace App\Http\Controllers;

use App\Models\Favorites;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function signOut() {
        Session::flush();
        Auth::logout();
  
        return response()->json([
            'status' => true,
        ], 200);
    }

    public function getFav()
    {
        $data = Favorites::where('user_id', "4057e221-7e0c-4e2e-a8ec-1f52626013e5")->get();

        return response()->json([
            'status' => true,
            'data' => $data,
        ], 200);
    }
    public function delFav($id)
    {
        $data = Favorites::where('user_id', Auth::user()->unique_id)->where('id', $id)->exists();

        if($data == true )
        {
            Favorites::where('user_id', Auth::user()->unique_id)->where('id', $id)->delete();

            return response()->json([
                'status' => true,
                'message' => "Favorite removed",
            ], 200);
        }
        else {
            return response()->json([
                'status' => false,
                'message' => "No favorite with #". $id ." found",
            ], 200);
        }
    }
    public function postFav()
    {
        $fav = new Favorites();

        $fav->title = request()->title;
        $fav->content = request()->content;
        $fav->user_id = Auth::user()->unique_id;
        $fav->save();

        return response()->json([
            'status' => true,
            'message' => "Favorite added",
            'data' => $fav
        ], 200);
    }

    public function searchWord(Request $request)
    {
        return "Search Word";
    }


}
