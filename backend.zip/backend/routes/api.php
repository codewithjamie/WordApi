<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*
    Register Route
*/
Route::post('register', [RegisterController::class, "RegisterUser"]);
Route::post('login', [LoginController::class, "LoginUser"]);


/*
    Favorite API
*/
// Route::middleware('auth:sanctum')->group(function () {
    Route::get('get-favorites', [UserController::class, "getFav"]);
    Route::delete('delete-favorite/id={id}', [UserController::class, "delFav"]);
    Route::post('store-favorite', [UserController::class, "postFav"]);
// });

/*
 Search word
*/
Route::middleware('throttle:2,2')->group(function () {
    Route::post('search-word', [UserController::class, "searchWord"]);
});